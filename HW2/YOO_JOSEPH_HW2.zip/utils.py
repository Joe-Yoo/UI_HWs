CAUSES = ['Mental Demand', 'Physical Demand', 'Temporal Demand', 'Performance', 'Effort', 'Frustration']
DESCRIPTIONS = [
    'How mentally demanding was the task?',
    'How physically demanding was the task? ',
    'How hurried or rushed was the pace of the task?',
    'How successful were you in accomplishing what you were asked to do?',
    'How hard did you have to work to accomplish your level of performance?',
    'How insecure, discouraged, irritated, stressed and annoyed were you?'
]