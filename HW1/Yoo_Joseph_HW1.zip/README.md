# HOMEWORK 1 - Demographics and Contact Form

**Name**: Joseph Yoo

**Email**: jyoo319@gatech.edu

**GT Username**: jyoo319

I did not do the extra credit.

I made it so that invalid characters couldn't be input in the text input boxes. For example, for phone number, only numbers can be typed in the input. That's pretty much it though, nothing else I can think of. 

No other build requirements other than Kivy.